package com.hkgoodvision.gvpos.constant;

public class FieldConstant {
	public static final String ORDER_LIST_ITEM_NAME = "ITEM_NAME";
	public static final String ORDER_LIST_ITEM_PRICE = "ITEM_PRICE";
	public static final String ORDER_LIST_ITEM_QTY = "ITEM_QTY";
}
