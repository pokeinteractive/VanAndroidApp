package com.vanapp.constant;

public class URLConstant {
	public static final  String URL_BASE = "http://van.poke.com.hk/messaging/index.php?";
	public static final  String URL_PHONE_CHECK = URL_BASE+ "action=phonecheck";
	
	public static final  String URL_GET_DRIVER_ID_BY_PHONE = "http://van.poke.com.hk/jsonapi/getDriverIdByPhone/";
}
