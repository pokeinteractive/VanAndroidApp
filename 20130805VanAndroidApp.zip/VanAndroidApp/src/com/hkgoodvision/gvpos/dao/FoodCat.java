package com.hkgoodvision.gvpos.dao;

import java.math.BigDecimal;

public class FoodCat {
	
	// the category of food.
	int foodCatId;
	
	String foodCatName;
	String foodCatNameEng;
	String foodCatNameOther;

	
}
